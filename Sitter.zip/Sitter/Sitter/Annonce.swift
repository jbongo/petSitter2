//
//  Annonce.swift
//  Sitter
//
//  Created by ECE Tech on 12/03/2018.
//  Copyright © 2018 ECE Tech. All rights reserved.
//

import UIKit

class Annonce: NSObject {
    var id = 0
    var titre = ""
    var contenu=""
    
}
